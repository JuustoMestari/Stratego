﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Stratego;
namespace Stratego_GUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Game plop;
        public List<Button> predictionButtons;
        public Position lastClick;
        public Button lastClickButton;
        public bool isSecond = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void mainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            predictionButtons = new List<Button>();
            
            Player p1 = new Player("David", SpaceType.Player1, PlayerColor.Red);
            Player p2 = new Player("Paul", SpaceType.Player2, PlayerColor.Blue);
            plop = new Game(p1, p2);

            int cpt = 0;
            for (int row = 0; row < 4; row++)
            {
                for (int col = 0; col < 10; col++)
                {
                    Position pos = new Position();
                    pos.col = col;
                    pos.row = row;
                    plop.setPieceOnGrid(plop.player2Pieces[cpt], pos);
                    Button gcb = new Button();
                    gcb.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 0, 0, 255));
                    gcb.Content = (int)plop.player2Pieces[cpt].pieceName;
                    gcb.Height = 10;
                    gcb.Width = 10;
                    gcb.HorizontalAlignment = HorizontalAlignment.Left;
                    gcb.VerticalAlignment = VerticalAlignment.Top;
                    gcb.FontSize = 4;
                    gcb.Tag = pos;
                    gcb.Name = "BLUE_" + cpt;
                    gcb.Click+=gcb_Click;
                    System.Windows.Controls.Grid.SetRow(gcb, row);
                    System.Windows.Controls.Grid.SetColumn(gcb, col);
                    boardGrid.Children.Add(gcb);
                    cpt++;
                }
            }
            cpt = 0;
            for (int row = 6; row < 10; row++)
            {
                for (int col = 0; col < 10; col++)
                {
                    Position pos = new Position();
                    pos.col = col;
                    pos.row = row;
                    plop.setPieceOnGrid(plop.player1Pieces[cpt], pos);
                    Button gcb = new Button();
                    gcb.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 255, 0, 0));
                    gcb.Content = (int)plop.player1Pieces[cpt].pieceName;
                    gcb.Height = 10;
                    gcb.Width = 10;
                    gcb.HorizontalAlignment = HorizontalAlignment.Left;
                    gcb.VerticalAlignment = VerticalAlignment.Top;
                    gcb.FontSize = 4;
                    gcb.Name = "RED_" + cpt;
                    gcb.Tag = pos;
                    gcb.Click += gcb_Click;
                    System.Windows.Controls.Grid.SetRow(gcb, row);
                    System.Windows.Controls.Grid.SetColumn(gcb, col);
                    boardGrid.Children.Add(gcb);
                    cpt++;
                }
            }
            for(int i=4;i<6;i++)
            {
                for (int j = 2; j < 4; j++)
                {
                    Button gcb = new Button();
                    gcb.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 117, 158, 255));
                    gcb.Background = new SolidColorBrush(Color.FromArgb(255, 24, 49, 107));
                    gcb.Content = "X";
                    gcb.Height = 10;
                    gcb.Width = 10;
                    gcb.HorizontalAlignment = HorizontalAlignment.Left;
                    gcb.VerticalAlignment = VerticalAlignment.Top;
                    gcb.FontSize = 4;
                   
                    gcb.IsEnabled = false;
                    System.Windows.Controls.Grid.SetRow(gcb, i);
                    System.Windows.Controls.Grid.SetColumn(gcb, j);
                    boardGrid.Children.Add(gcb);
                }
            }
            for (int i = 4; i < 6; i++)
            {
                for (int j = 6; j < 8; j++)
                {
                    Button gcb = new Button();
                    gcb.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 117, 158, 255));
                    gcb.Background = new SolidColorBrush(Color.FromArgb(255, 24, 49, 107));
                    gcb.Content = "X";
                    gcb.Height = 10;
                    gcb.Width = 10;
                    gcb.HorizontalAlignment = HorizontalAlignment.Left;
                    gcb.VerticalAlignment = VerticalAlignment.Top;
                    gcb.FontSize = 4;
                    gcb.IsEnabled = false;
                    System.Windows.Controls.Grid.SetRow(gcb, i);
                    System.Windows.Controls.Grid.SetColumn(gcb, j);
                    boardGrid.Children.Add(gcb);
                }
            }
            plop.start();
        }

        void gcb_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            Position pos= (Position)btn.Tag;
            lastClick = pos;
            lastClickButton = btn;
            clearPredictions();
            int returnValue;
            foreach(Position p in plop.getMoves(pos,out returnValue))
            {
                Button gcb = new Button();
                gcb.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 0, 255, 0));
                gcb.Height = 10;
                gcb.Width = 10;
                gcb.HorizontalAlignment = HorizontalAlignment.Left;
                gcb.VerticalAlignment = VerticalAlignment.Top;
                gcb.FontSize = 4;
                gcb.Name="getmove";
                gcb.Click+= predictionClick;
                gcb.Tag = p;
                System.Windows.Controls.Grid.SetRow(gcb, p.row);
                System.Windows.Controls.Grid.SetColumn(gcb, p.col);
                boardGrid.Children.Add(gcb);
                predictionButtons.Add(gcb);
            }
            if (isSecond)
            {
                clearPredictions();
                
            }
            isSecond = !isSecond;
           // System.Windows.Controls.Grid.SetRow(btn,plop.row-1);
           //System.Windows.Controls.Grid.SetColumn(btn, plop.col);
           // plop.col--;
           // plop.row--;
            //btn.Tag = plop;
            //MessageBox.Show(btn.Name);
        }
        void predictionClick(object sender, RoutedEventArgs e)
        {
            isSecond = !isSecond;
            Button btn = (Button)sender;
            Position pos = (Position)btn.Tag;
            
            lastClickButton.Tag = pos;

            switch(plop.movePiece(lastClick, pos))
            {
                case 1: System.Windows.Controls.Grid.SetRow(lastClickButton, pos.row);
                        System.Windows.Controls.Grid.SetColumn(lastClickButton, pos.col);
                    break;
                case 10: System.Windows.Controls.Grid.SetRow(lastClickButton, pos.row);
                        System.Windows.Controls.Grid.SetColumn(lastClickButton, pos.col); 
                        clearPiece(pos);
                    break;
                case 20: clearPiece(lastClick);
                            clearPiece(pos);
                    break;
                case 30: clearPiece(lastClick);
                    break;
                case 50: 
                    break;
                default: Console.WriteLine("Move not allowed !");
                    break;
            }
            clearPredictions();
        }
        void clearPredictions()
        {
            foreach (Button b in predictionButtons)
            {
                boardGrid.Children.Remove(b);
            }
            predictionButtons.Clear();
        }
        void clearPiece(Position pos)
        {
            for (int i = 0; i < boardGrid.Children.Count; i++)
            {
                if (System.Windows.Controls.Grid.GetRow(boardGrid.Children[i]) == pos.row && System.Windows.Controls.Grid.GetColumn(boardGrid.Children[i]) == pos.col)
                {
                    boardGrid.Children.Remove(boardGrid.Children[i]);
                    break;
                }
            }
        }
        
    }
}
